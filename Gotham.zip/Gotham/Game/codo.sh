codo ./src/GOTHAM-GF --private --undocumented --title "Gotham API Docs" --output ./htdocs/documentation
